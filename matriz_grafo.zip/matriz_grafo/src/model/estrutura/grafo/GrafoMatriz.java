package model.estrutura.grafo;

import java.util.*;

public class GrafoMatriz<T>{
    private int [][] matriz;
    private String[] labels;
    private int [][] matrizremove;

    public GrafoMatriz(String[] labels){
        this.labels=labels;
        this.matriz = new int[labels.length][labels.length];
    }
    public void link(String label1, String label2){
        int index_label1 = Arrays.asList(this.labels).indexOf(label1);
        int index_label2 = Arrays.asList(this.labels).indexOf(label2);
        this.matriz[index_label1][index_label2]=1;
        this.matriz[index_label2][index_label1]=1;
    }

    public void remove (String label){
        int indexRemove = Arrays.asList(this.labels).indexOf(label);//index do elemento a ser removido
        int [][] matrizRemove = new int[this.labels.length-1][this.labels.length-1];//nova matriz
        String[] novosLabels = new String[this.labels.length-1];//novo vetor de labels
        int novoIndex = 0;//copia labels

        for(int i=0;i<this.labels.length;i++){
            if(i!=indexRemove){
                novosLabels[novoIndex] = this.labels[i];
                novoIndex++;
            }
        }
    
    //copia matriz o elemento removido
    int linhaNova=0;
    for(int i=0;i<this.matriz.length;i++){
        if(i==indexRemove){
            continue;
        }
        int colunaNova = 0;

        for(int j =0;j<this.matriz.length;j++){
            if(j==indexRemove){
                continue;
            }
            matrizRemove[linhaNova][colunaNova]=this.matriz[i][j];
            colunaNova++;
            }
        linhaNova++;
    }

    this.matriz=matrizRemove;
    this.labels=novosLabels;
    }
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < this.labels.length; i++) {
            builder.append(this.labels[i] + ": ");
            for(int j = 0; j < this.labels.length; j++ ) {
                if( this.matriz[i][j] == 1 ){
                    builder.append( this.labels[j] + " ");
                }
            }
            builder.append("\r\n");
        }
        return (builder.toString());
    }
}