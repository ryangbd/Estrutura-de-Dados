package view;

import controller.GrafoMatrizController;

public class GrafoMatriz{
    public static void main(String[] args) {
        try{
            GrafoMatrizController obj =
                    new GrafoMatrizController();

            System.out.println( obj.teste() );
        } catch( Exception e ){
            e.printStackTrace();
        }
    }
}

/*
javac -s ./src/ -d ./dist/ ./src/model/estrutura/grafo/GrafoMatriz.java ./src/controller/GrafoMatrizController.java ./src/view/GrafoMatriz.java
java -classpath dist view/GrafoMatriz
*/