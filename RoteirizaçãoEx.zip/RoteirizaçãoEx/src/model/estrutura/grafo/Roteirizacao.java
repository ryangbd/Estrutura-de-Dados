import java.util.*;

public class Roteirizacao {

    // matriz de distâncias (0 = sem conexão)
    private static int[][] matriz;
    private static String[] cidades;

    static String CD1 = "São Paulo";
    static String CD2 = "Governador Valadares";
    static String Fabrica = "Belo Horizonte";

    public static void main(String[] args) {
        construirGrafo();

        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Sistema de Roteirização FIAT ===");
        System.out.println("Fábrica: " + Fabrica);
        System.out.println("CD1: " + CD1);
        System.out.println("CD2: " + CD2);
        System.out.println();

        while (true) {
            System.out.print("Digite a cidade de destino (ou 'sair' para encerrar): ");
            String destino = scanner.nextLine().trim();

            if (destino.equalsIgnoreCase("sair")) break;

            if (indexOf(destino) == -1) {
                System.out.println("Cidade não encontrada. Tente novamente.");
                System.out.println();
                continue;
            }

            System.out.println();
            System.out.println("--- Resultado para: " + destino + " ---");

            List<String> rotaFabrica = dijkstra(Fabrica, destino);
            int distFabrica = calcularDistancia(rotaFabrica);
            System.out.println("Se for pela fábrica: " + formatarRota(rotaFabrica) + ": " + String.format("%05d", distFabrica) + " Km");

            List<String> rotaCD1 = dijkstra(CD1, destino);
            List<String> rotaCD2 = dijkstra(CD2, destino);

            String cdMaisProximo;
            List<String> rotaCD;
            int distCD;

            if (rotaCD1 != null && (rotaCD2 == null || calcularDistancia(rotaCD1) <= calcularDistancia(rotaCD2))) {
                cdMaisProximo = CD1;
                rotaCD = rotaCD1;
                distCD = calcularDistancia(rotaCD1);
            } else {
                cdMaisProximo = CD2;
                rotaCD = rotaCD2;
                distCD = calcularDistancia(rotaCD2);
            }

            if (rotaCD != null) {
                System.out.println("Se for pelo CD próximo (" + cdMaisProximo + "): "
                        + formatarRota(rotaCD) + ": " + String.format("%05d", distCD) + " Km");
            } else {
                System.out.println("Nenhum CD consegue atender esta cidade.");
            }

            System.out.println();
        }

        scanner.close();
        System.out.println("Sistema encerrado.");
    }

    // monta a lista de cidades e a matriz de distâncias
    static void construirGrafo() {
        cidades = new String[]{
            "Belo Horizonte", "Governador Valadares", "Manhuaçu", "Uberaba",
            "Juiz de Fora", "Uberlândia", "Patos de Minas", "Colatina",
            "Vitória", "Rio de Janeiro", "Campos dos Goytacazes",
            "São José dos Campos", "São Paulo", "Campinas", "São Carlos",
            "Ribeirão Preto", "Franca", "São José do Rio Preto"
        };

        // cria matriz zerada (0 = sem conexão)
        matriz = new int[cidades.length][cidades.length];

        link("Belo Horizonte",        "Governador Valadares", 313);
        link("Belo Horizonte",        "Manhuaçu",             279);
        link("Belo Horizonte",        "Uberaba",              476);
        link("Belo Horizonte",        "Juiz de Fora",         260);
        link("Uberaba",               "Uberlândia",           105);
        link("Uberlândia",            "Patos de Minas",       222);
        link("Governador Valadares",  "Colatina",             216);
        link("Manhuaçu",              "Governador Valadares", 198);
        link("Manhuaçu",              "Vitória",              233);
        link("Manhuaçu",              "Juiz de Fora",         290);
        link("Juiz de Fora",          "Rio de Janeiro",       181);
        link("Rio de Janeiro",        "Campos dos Goytacazes",277);
        link("Campos dos Goytacazes", "Vitória",              240);
        link("Rio de Janeiro",        "São José dos Campos",  341);
        link("São José dos Campos",   "São Paulo",             79);
        link("São Paulo",             "Campinas",             111);
        link("Campinas",              "São Carlos",           142);
        link("São Carlos",            "Ribeirão Preto",        99);
        link("Ribeirão Preto",        "Franca",                89);
        link("Ribeirão Preto",        "Uberlândia",           278);
        link("Uberlândia",            "São José do Rio Preto",285);
        link("São José do Rio Preto", "São Carlos",           206);
    }

    //guarda a distância no lugar do 1
    static void link(String cidade1, String cidade2, int distancia) {
        int i = indexOf(cidade1);
        int j = indexOf(cidade2);
        matriz[i][j] = distancia;
        matriz[j][i] = distancia;
    }

    // retorna o índice de uma cidade no vetor
    static int indexOf(String cidade) {
        return Arrays.asList(cidades).indexOf(cidade);
    }

    // dijkstra percorrendo a matriz linha por linha
    static List<String> dijkstra(String origem, String destino) {
        int origemIdx  = indexOf(origem);
        int destinoIdx = indexOf(destino);
        if (origemIdx == -1 || destinoIdx == -1) return null;

        int n = cidades.length;
        int[] distancias   = new int[n];
        int[] anteriores   = new int[n];
        boolean[] visitado = new boolean[n];

        Arrays.fill(distancias, Integer.MAX_VALUE);
        Arrays.fill(anteriores, -1);
        distancias[origemIdx] = 0;

        for (int i = 0; i < n; i++) {
            // pega o nó não visitado com menor distância acumulada
            int atual = -1;
            for (int j = 0; j < n; j++) {
                if (!visitado[j] && (atual == -1 || distancias[j] < distancias[atual])) {
                    atual = j;
                }
            }

            if (atual == destinoIdx) break;
            visitado[atual] = true;

            // percorre a linha da matriz
            for (int j = 0; j < n; j++) {
                if (matriz[atual][j] != 0) { // tem conexão?
                    int novaDist = distancias[atual] + matriz[atual][j];
                    if (novaDist < distancias[j]) {
                        distancias[j] = novaDist;
                        anteriores[j] = atual;
                    }
                }
            }
        }

        if (distancias[destinoIdx] == Integer.MAX_VALUE) return null;

        // reconstrói o caminho de trás pra frente
        List<String> caminho = new ArrayList<>();
        int atual = destinoIdx;
        while (atual != -1) {
            caminho.add(0, cidades[atual]);
            atual = anteriores[atual];
        }
        return caminho;
    }

    static int calcularDistancia(List<String> rota) {//AQUI ELE CALCULA DISTANCIA (MEIO OBVIO)
        if (rota == null || rota.size() < 2) return 0;
        int total = 0;
        for (int i = 0; i < rota.size() - 1; i++) {
            int a = indexOf(rota.get(i));
            int b = indexOf(rota.get(i + 1));
            total += matriz[a][b];
        }
        return total;
    }

    static String formatarRota(List<String> rota) {
        return String.join(" > ", rota);
    }
}