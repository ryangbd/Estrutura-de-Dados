package model.estrutura.arvore;

import model.estrutura.arvore.*;
import model.estrutura.lista.*;

public class ArvoreBinaria<T extends Comparable> {
    private No<T> raiz;
    private int tamanho = 0;

    public ArvoreBinaria() {
        this.raiz = null;
    }

    public void add(T valor) {
        No<T> novo = new No<>(valor);
        tamanho++;
        if (raiz == null) {
            this.raiz = novo;
            return;
        }

        No<T> atual = this.raiz;
        while (true) {
            if (novo.getValor().compareTo(atual.getValor()) == -1) {
                if (atual.getMenor() != null) {
                    atual = atual.getMenor();
                } else {
                    atual.setMenor(novo);
                    break;
                }
            } else {
                if (atual.getMaior() != null) {
                    atual = atual.getMaior();
                } else {
                    atual.setMaior(novo);
                    break;
                }
            }
        }
    }

    No<T> atual = this.raiz;

    public ListaEncadeadaSimples ordem() {
        ListaEncadeadaSimples lista = new ListaEncadeadaSimples();
        No<T> atual = this.raiz;
        ordem(atual, lista);
        return lista;
    }

    public ListaEncadeadaSimples preOrdem() {
        ListaEncadeadaSimples lista = new ListaEncadeadaSimples();
        preOrdem(this.raiz, lista);
        return lista;
    }

    public ListaEncadeadaSimples posOrdem() {
        ListaEncadeadaSimples lista = new ListaEncadeadaSimples();
        posOrdem(atual, lista);
        return lista;
    }

    private void ordem(No<T> atual, ListaEncadeadaSimples lista) {
        if (atual != null) {
            ordem(atual.getMenor(), lista);
            lista.append(atual.getValor());
            ordem(atual.getMaior(), lista);
        }
    }

    private void preOrdem(No<T> atual, ListaEncadeadaSimples lista) {
        if (atual != null) {
            lista.append(atual.getValor());
            preOrdem(atual.getMenor(), lista);
            preOrdem(atual.getMaior(), lista);
        }
    }

    private void posOrdem(No<T> atual, ListaEncadeadaSimples lista) {
        if (atual != null) {
            posOrdem(atual.getMenor(), lista);
            posOrdem(atual.getMaior(), lista);
            lista.append(atual.getValor());
        }
    }

    public boolean remove(T valor) {
        // buscar o No na árvore
        No<T> atual = this.raiz;
        No<T> paiAtual = null;

        while (atual != null) {
            if (valor.compareTo(atual.getValor()) == 0) {
                break;
            } else if (valor.compareTo(atual.getValor()) == -1) {
                // valor procurado é menor que o atual
                paiAtual = atual;
                atual = atual.getMenor();
            } else {
                paiAtual = atual;
                atual = atual.getMaior();
            }
        }

        // verifica se existe o No
        if (atual == null) {
            return false;
        }

        // No tem 2 filhos OU No tem somente filho à direita
        if (atual.getMaior() != null) {
            No<T> substituto = atual.getMaior();
            No<T> paiSubstituto = atual;

            while (substituto.getMenor() != null) {
                paiSubstituto = substituto;
                substituto = substituto.getMenor();
            }

            substituto.setMenor(atual.getMenor());

            if (paiAtual != null) {
                if (atual.getValor().compareTo(paiAtual.getValor()) == -1) {
                    paiAtual.setMenor(substituto);
                } else {
                    paiAtual.setMaior(substituto);
                }
            } else {
                // se não tem paiAtual, então é a raiz
                this.raiz = substituto;
                paiSubstituto.setMenor(null);
                this.raiz.setMenor(atual.getMenor());
            }

            // remove o No da arvore
            if (substituto.getValor().compareTo(paiSubstituto.getValor()) != 0) {
                paiSubstituto.setMenor(null);
            } else {
                paiSubstituto.setMaior(null);
            }

        } else if (atual.getMenor() != null) {
            // tem filho só à esquerda
            No<T> substituto = atual.getMenor();
            No<T> paiSubstituto = atual;

            while (substituto.getMaior() != null) {
                paiSubstituto = substituto;
                substituto = substituto.getMaior();
            }

            if (paiAtual != null) {
                if (atual.getValor().compareTo(paiAtual.getValor()) == -1) {
                    paiAtual.setMenor(substituto);
                } else {
                    paiAtual.setMaior(substituto);
                }
            } else {
                // se for a raiz
                this.raiz = substituto;
            }

            // remove o No da arvore
            if (substituto.getValor().compareTo(paiSubstituto.getValor()) == -1) {
                paiSubstituto.setMenor(null);
            } else {
                paiSubstituto.setMaior(null);
            }

        } else {
            // não tem filho (folha)
            if (paiAtual != null) {
                if (atual.getValor().compareTo(paiAtual.getValor()) == -1) {
                    paiAtual.setMenor(null);
                } else {
                    paiAtual.setMaior(null);
                }
            } else {
                // é a raiz
                this.raiz = null;
            }
        }

        return true;
    }
}